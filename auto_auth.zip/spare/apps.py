from django.apps import AppConfig


class SpareConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spare'
